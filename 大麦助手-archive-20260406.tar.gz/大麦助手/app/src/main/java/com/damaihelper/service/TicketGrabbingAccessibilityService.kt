        submitNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        Log.i(TAG, "✅ 步骤 3 完成：订单已提交")
        return true
    }


    /**
     * 检查是否已在演出详情页
     */
    private suspend fun checkIfInDetailPage(keyword: String): Boolean {
        // 检查是否有演出详情页的特征元素
        val detailIndicators = arrayOf(
            "预约抢票", "预约想看", "立即购买", "立即预订", "选座购票",
            keyword, "${keyword}演唱会", "${keyword}巡演"
        )
        
        for (indicator in detailIndicators) {
            val node = findNodeByText(indicator)
            if (node != null) {
                Log.i(TAG, "✅ 找到详情页特征：$indicator")
                return true
            }
        }
        
        return false
    }
    
    /**
     * 点击预约或购买按钮
     */
    private suspend fun clickReserveOrBuyButton() {
        // 优先查找"预约抢票"按钮
        val reserveBtn = findNodeByAnyText(
            "预约抢票", "预约想看", "提前选票档",
            "cn.damai:id/reserveBtn"
        )
        
        if (reserveBtn != null) {
            reserveBtn.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            Log.i(TAG, "✅ 点击预约抢票按钮")
            return
        }
        
        // 查找"立即购买"按钮
        val buyBtn = findNodeByAnyText(
            "立即购买", "立即预订", "选座购票",
            "cn.damai:id/buyBtn"
        )
        
        if (buyBtn != null) {
            buyBtn.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            Log.i(TAG, "✅ 点击购买按钮")
            return
        }
        
        Log.w(TAG, "⚠️ 未找到预约/购买按钮，尝试继续...")
    }
}
